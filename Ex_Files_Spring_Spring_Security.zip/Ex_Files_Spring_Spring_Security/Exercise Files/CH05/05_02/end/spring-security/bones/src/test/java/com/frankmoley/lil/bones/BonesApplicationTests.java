package com.frankmoley.lil.bones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BonesApplicationTests {

    @Test
    void contextLoads() {
    }

}
