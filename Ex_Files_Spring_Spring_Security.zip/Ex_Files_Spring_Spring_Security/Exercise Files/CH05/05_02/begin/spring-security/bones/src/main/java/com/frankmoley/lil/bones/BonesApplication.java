package com.frankmoley.lil.bones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BonesApplication {

    public static void main(String[] args) {
        SpringApplication.run(BonesApplication.class, args);
    }

}
